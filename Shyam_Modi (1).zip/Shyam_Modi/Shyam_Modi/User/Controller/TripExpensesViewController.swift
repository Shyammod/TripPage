//
//  TripExpenses.swift
//  Shyam_Modi
//
import UIKit

class TripExpensesViewController: UIViewController {
    
    private let manager = DatabaseManager()
    var user: UserData?
    private var users: [UserData] = []
    
    var expense: UserExpenses?
    private var expenses: [UserExpenses] = []
  

    override func viewDidLoad() {
        super.viewDidLoad()
        printTripTitle()
      //  printTripExpenses()
        
        tripExpenseList.register(UINib(nibName: "ExpensesCell", bundle: nil), forCellReuseIdentifier: "ExpensesCell")
        tripExpenseList.register(UITableViewCell.self, forCellReuseIdentifier: "PlaceholderCell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        expenses = manager.fetchExpenses()
        
        for exp in expenses {
            _ = exp.expenseName
            }
        print("Fetched users: \(expenses)")
        tripExpenseList.reloadData()
    }
    
    @IBOutlet weak var tripTitleLabel: UILabel!
    @IBOutlet weak var expenseName: UITextField!
    @IBOutlet weak var expenseAmount: UITextField!
    @IBOutlet weak var tripExpenseList: UITableView!
    
    func printTripTitle(){
        if let user = user {
            tripTitleLabel.text = user.tripName
        } else {
            print("No user object passed")
        }
    }
    @IBAction func save(_ sender: UIButton) {
        guard let expenseNameInput = expenseName.text, !expenseNameInput.isEmpty else{
            openAlert(message: "Please Enter Your Expense Name")
            return
        }
        guard let expenseAmountText = expenseAmount.text, !expenseAmountText.isEmpty,
        let setexpenseAmount = Double(expenseAmountText)else{
            openAlert(message: "Please Enter Your Expense Amount")
            return
        }
        let setTripName = tripTitleLabel.text ?? "NA"
        let newExpense = Expenses(tripName: setTripName,expenseName: expenseNameInput, expenseAmount: setexpenseAmount)
        
        manager.addexpense(newExpense)
        expenseName.text = ""
        expenseAmount.text = ""
        navigationController?.popViewController(animated: true)
        tripExpenseList.reloadData()
       
    }
    
    @IBAction func reset(_ sender: UIButton) {
        expenseName.text = ""
        expenseAmount.text = ""
    }
}

extension TripExpensesViewController{
    func openAlert(message: String){
        let alertController  = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okay = UIAlertAction(title: "Okay", style: .default)
        alertController.addAction(okay)
        present(alertController, animated: true)
    }
}

extension TripExpensesViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //users.count
        return expenses.isEmpty ? 1 : expenses.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if expenses.isEmpty {
                   let cell = tableView.dequeueReusableCell(withIdentifier: "PlaceholderCell", for: indexPath)
                   cell.textLabel?.text = "Add new Expense"
                   cell.textLabel?.textAlignment = .center
                   cell.selectionStyle = .none
            
            print("Displaying placeholder cell")
                   return cell
               } else {
                   guard let cell = tableView.dequeueReusableCell(withIdentifier: "ExpensesCell") as? ExpensesCell else {
                               print("Failed to dequeue UserCell")
                               return UITableViewCell()
                           }
                           let user = expenses[indexPath.row]
                          // print("Configuring cell with tripName: \(user.tripName ?? "N/A"), destination: \(user.expenseName ?? "N/A")")
                           cell.tableExpense = user
                           //cell.users = user
                           return cell
       }
    }
}


extension TripExpensesViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
    
        guard !expenses.isEmpty else { return nil }
        
        let delete = UIContextualAction(style: .destructive, title: "Delete") { _, _, _ in
            self.manager.deleteExpense(userEntity: self.expenses[indexPath.row])
            self.expenses.remove(at: indexPath.row)
            self.tripExpenseList.reloadData()
        }
        return UISwipeActionsConfiguration(actions: [delete])
    }
}

