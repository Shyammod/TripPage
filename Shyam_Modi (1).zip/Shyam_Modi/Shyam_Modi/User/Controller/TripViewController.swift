//
//  TripViewController.swift
//  Shyam_Modi
//
import UIKit
import CoreLocation
import MapKit


class TripViewController: UIViewController, CLLocationManagerDelegate  {
  
    let locationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        mapView.delegate = self
          locationManager.delegate = self
                locationManager.requestWhenInUseAuthorization()
                locationManager.startUpdatingLocation()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        userDetailConfiguration()
        showCarRoute(UIButton())
        fetchDestinationWeather()
    }
    private var users: [UserData] = []
    @IBOutlet weak var startingPoint: UILabel!
    @IBOutlet weak var destination: UILabel!
    @IBOutlet weak var startingDate: UILabel!
    @IBOutlet weak var endingDate: UILabel!
    
    @IBOutlet weak var zoomSlider: UISlider!
    
    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var conditionLabel: UILabel!
    @IBOutlet weak var temperature: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var windSpeedLabel: UILabel!
    @IBOutlet weak var iconImageView: UIImageView!
    
    
    var user: UserData?
    
    func userDetailConfiguration(){
        if let user{
            navigationItem.title = user.tripName
            startingPoint.text = user.startingLocation
            destination.text = user.destination
            startingDate.text = user.startingDate
            endingDate.text = user.endingDate
            
            //imageSelectedByUser = true
            print("\(user.tripName!)")
        }else{
            navigationItem.title = "No User"
           // formButton.setTitle("Register", for: .normal)
            print("fail")
        }
    }
    
    @IBAction func showCarRoute(_ sender: UIButton) {
        showRoute(transportType: .automobile)
    }
    
    
    @IBAction func showWalkingRoute(_ sender: UIButton) {
        showRoute(transportType: .walking)
    }
    
    func showRoute(transportType: MKDirectionsTransportType) {
        guard let startingLocation = startingPoint.text,
              let destinationLocation = destination.text else { return }
        
        let geocoder = CLGeocoder()
        
        geocoder.geocodeAddressString(startingLocation) { [weak self] (placemarks, error) in
            guard let strongSelf = self,
                  let startPlacemark = placemarks?.first,
                  let startCoordinate = startPlacemark.location?.coordinate else { return }
            
            geocoder.geocodeAddressString(destinationLocation) { (placemarks, error) in
                guard let endPlacemark = placemarks?.first,
                      let endCoordinate = endPlacemark.location?.coordinate else { return }
                
                let startMapItem = MKMapItem(placemark: MKPlacemark(coordinate: startCoordinate))
                let endMapItem = MKMapItem(placemark: MKPlacemark(coordinate: endCoordinate))
                
                let request = MKDirections.Request()
                request.source = startMapItem
                request.destination = endMapItem
                request.transportType = transportType
                
                let directions = MKDirections(request: request)
                directions.calculate { response, error in
                    guard let route = response?.routes.first else { return }
                    
                    strongSelf.mapView.removeOverlays(strongSelf.mapView.overlays)
                    strongSelf.mapView.addOverlay(route.polyline, level: .aboveRoads)
                    
                    let rect = route.polyline.boundingMapRect
                    strongSelf.mapView.setRegion(MKCoordinateRegion(rect), animated: true)
                }
            }
        }
    }
    
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        let zoomLevel = Double(sender.value) * 0.1 // Adjust the multiplier as needed
                var region = mapView.region
                region.span.latitudeDelta = zoomLevel
                region.span.longitudeDelta = zoomLevel
                mapView.setRegion(region, animated: true)
    }
    
    func fetchDestinationWeather() {
            guard let destination = user?.destination else { return }
            
            let geocoder = CLGeocoder()
            geocoder.geocodeAddressString(destination) { [weak self] (placemarks, error) in
                guard let strongSelf = self,
                      let location = placemarks?.first?.location else { return }
                
                let latitude = location.coordinate.latitude
                let longitude = location.coordinate.longitude
                strongSelf.getWeatherData(lat: latitude, lon: longitude)
            }
        }
    func getWeatherData(lat: Double, lon: Double) {
        let apiKey = "3c86cdb94245fa2ca3d0c97d28abc112"
        let urlString = "https://api.openweathermap.org/data/2.5/weather?lat=\(lat)&lon=\(lon)&appid=\(apiKey)&units=metric"
        
        guard let url = URL(string: urlString) else { return }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                print("Error fetching weather data: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            do {
                let weatherData = try JSONDecoder().decode(WeatherResponse.self, from: data)
                DispatchQueue.main.async {
                    self.updateUI(with: weatherData)
                }
            } catch {
                print("Failed to decode JSON: \(error)")
            }
        }
        
        task.resume()
    }

    func updateUI(with response: WeatherResponse) {
        let temperature = response.main.temp
        let humidity = response.main.humidity
        let windSpeed = response.wind.speed
        let condition = response.weather.first?.description ?? ""
        let icon = response.weather.first?.icon ?? ""

        // Ensure labels are properly initialized
        self.temperature.text = "\(temperature)°C"
        conditionLabel.text = condition
        humidityLabel.text = "Humidity: \(humidity)%"
        windSpeedLabel.text = "Wind Speed: \(windSpeed) m/s"
        
        // Load the weather icon image
        loadImage(icon: icon)
    }

    func loadImage(icon: String) {
        let urlString = "https://openweathermap.org/img/wn/\(icon)@2x.png"
        guard let url = URL(string: urlString) else { return }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            guard let data = data, error == nil else {
                print("Error fetching weather icon: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            DispatchQueue.main.async {
                self?.iconImageView.image = UIImage(data: data)
            }
        }
        task.resume()
    }
    
    func viewCard(user: UserData? = nil) {
        guard let cardVC = self.storyboard?.instantiateViewController(withIdentifier: "TripExpensesViewController") as? TripExpensesViewController else {
            print("Fail to load card controller")
            return
        }
        cardVC.user = user // Set the user object to the destination view controller
        print("Passing user: \(String(describing: user))") 
        navigationController?.pushViewController(cardVC, animated: true)
    }

    
    @IBAction func barButtonItemTapped(_ sender: UIBarButtonItem) {
        viewCard(user: user)
    }
    

}

extension TripViewController: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polyline = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: polyline)
            renderer.strokeColor = .blue
            renderer.lineWidth = 5.0
            return renderer
        }
        return MKOverlayRenderer(overlay: overlay)
    }
}

