
//  TripListViewController.swift
//  Shyam_Modi
//
import UIKit

class TripListViewController: UIViewController {

    @IBOutlet weak var tripTableView: UITableView!
    
    private var users: [UserData] = []
    private let manager = DatabaseManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        tripTableView.register(UINib(nibName: "UserCell", bundle: nil), forCellReuseIdentifier: "UserCell")
        tripTableView.register(UITableViewCell.self, forCellReuseIdentifier: "PlaceholderCell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        users = manager.fetchUser()
        for user in users {
            _ = user.tripName // Assuming 'name' is a property of UserData
            }
        print("Fetched users: \(users)")
        tripTableView.reloadData()
    }
   
    func viewCard(user: UserData? = nil){
        guard let cardVC = self.storyboard?.instantiateViewController(withIdentifier: "TripViewController") as? TripViewController else {
            print("Fail to load card controller")
            return
        }
        cardVC.user = user
        navigationController?.pushViewController(cardVC, animated: true)
    }
    
}

extension TripListViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //users.count
        return users.isEmpty ? 1 : users.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if users.isEmpty {
                   let cell = tableView.dequeueReusableCell(withIdentifier: "PlaceholderCell", for: indexPath)
                   cell.textLabel?.text = "Add new Trip"
                   cell.textLabel?.textAlignment = .center
                   cell.selectionStyle = .none
            
            
            print("Displaying placeholder cell")
                   return cell
               } else {
                   guard let cell = tableView.dequeueReusableCell(withIdentifier: "UserCell") as? UserCell else {
                               print("Failed to dequeue UserCell")
                               return UITableViewCell()
                           }
                           let user = users[indexPath.row]
                           print("Configuring cell with tripName: \(user.tripName ?? "N/A"), destination: \(user.destination ?? "N/A")")
                           cell.user = user
                           return cell
               }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if users.isEmpty {
               print("Placeholder cell tapped")
               return
           }
           
           viewCard(user: users[indexPath.row])

    }
}


extension TripListViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
    
        guard !users.isEmpty else { return nil }
        
        let delete = UIContextualAction(style: .destructive, title: "Delete") { _, _, _ in
            self.manager.deleteUser(userEntity: self.users[indexPath.row])
            self.users.remove(at: indexPath.row)
            self.tripTableView.reloadData()
        }
        let card = UIContextualAction(style: .normal, title: "") { _, _, _ in
            self.viewCard(user: self.users[indexPath.row])
        }
        card.backgroundColor = .blue
        return UISwipeActionsConfiguration(actions: [delete])
    }
}

