//
//  ViewController.swift
//  Shyam_Modi
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tripNameInput: UITextField!
    @IBOutlet weak var startingLocationInput: UITextField!
    @IBOutlet weak var destinationInput: UITextField!
    @IBOutlet weak var startingDateInput: UITextField!
    @IBOutlet weak var endDateInput: UITextField!
    @IBOutlet weak var bioInput: UITextView!
    
    private let manager = DatabaseManager()
    var user: UserData?
    private let startingDatePicker = UIDatePicker()
    private let endDatePicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        configureDatePickers()
        userDetailConfiguration()
    }
    func configureDatePickers() {
            // Configure Starting Date Picker
            startingDatePicker.datePickerMode = .date
            startingDatePicker.preferredDatePickerStyle = .wheels
            startingDateInput.inputView = startingDatePicker
            startingDatePicker.addTarget(self, action: #selector(startingDateChanged), for: .valueChanged)
            
            // Configure End Date Picker
            endDatePicker.datePickerMode = .date
            endDatePicker.preferredDatePickerStyle = .wheels
            endDateInput.inputView = endDatePicker
            endDatePicker.addTarget(self, action: #selector(endingDateChanged), for: .valueChanged)
            
            
            let toolbar = UIToolbar()
            toolbar.sizeToFit()
            let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(donePressed))
            toolbar.setItems([doneButton], animated: true)
            startingDateInput.inputAccessoryView = toolbar
            endDateInput.inputAccessoryView = toolbar
        }
        
        @objc func startingDateChanged() {
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            formatter.timeStyle = .none
            startingDateInput.text = formatter.string(from: startingDatePicker.date)
        }
        
        @objc func endingDateChanged() {
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            formatter.timeStyle = .none
            endDateInput.text = formatter.string(from: endDatePicker.date)
        }
        
        @objc func donePressed() {
            view.endEditing(true)
        }
    
    func userDetailConfiguration(){
        navigationItem.title = "Add Trip"
        tripNameInput.text = user?.tripName
        startingLocationInput.text = user?.startingLocation
        destinationInput.text = user?.destination
        startingDateInput.text = user?.startingDate
        endDateInput.text = user?.endingDate
        bioInput.text = user?.bio
    }
    
    @IBAction func save(_ sender: UIButton) {
        guard let tripName = tripNameInput.text, !tripName.isEmpty else{
            openAlert(message: "Please enter your trip name")
            return
        }
        guard let startingLocation = startingLocationInput.text, !startingLocation.isEmpty else{
            openAlert(message: "Please enter your starting date")
            return
        }
        
        guard let destination = destinationInput.text, !destination.isEmpty else{
            openAlert(message: "Please enter your destination")
            return
        }
        
        guard let startingDate = startingDateInput.text, !startingDate.isEmpty else{
            openAlert(message: "Please enter your starting date")
            return
        }
        guard let endingDate = endDateInput.text, !endingDate.isEmpty else{
            openAlert(message: "Please enter Ending Date")
            return
        }
        guard let bio = bioInput.text, !bio.isEmpty else{
            openAlert(message: "Please enter your trip description")
            return
        }
        
        let newUser = UserModel(tripName: tripName, startingLocation: startingLocation, destination: destination, startingDate: startingDate, endingDate: endingDate, bio: bio)
    
        manager.adduser(newUser)
        navigationController?.popViewController(animated: true)
        
        tripNameInput.text = ""
        startingLocationInput.text = ""
        destinationInput.text = ""
        startingDateInput.text = ""
        endDateInput.text = ""
    }
    
}

extension ViewController{
    func openAlert(message: String){
        let alertController  = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okay = UIAlertAction(title: "Okay", style: .default)
        alertController.addAction(okay)
        present(alertController, animated: true)
    }
}


