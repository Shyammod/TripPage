//
//  UserModel.swift
//  Shyam_Modi

import Foundation

struct UserModel{
    let tripName:String
    let startingLocation: String
    let destination: String
    var startingDate: String
    let endingDate: String
    let bio: String
}

struct Expenses{
    let tripName: String
    let expenseName: String
    let expenseAmount: Double
}
