//
//  ExpensesCell.swift
//  Shyam_Modi

import UIKit

class ExpensesCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBOutlet weak var expenseName: UILabel!
    @IBOutlet weak var expenses: UILabel!
    
    var tableExpense: UserExpenses?{
        didSet{ //property observer
            userConfiguration()
        }
    }
    
    func userConfiguration(){
        guard let tableExpense else{
            return
        }
        
        expenseName.text = tableExpense.expenseName  ?? "N/A" //trip name
        expenses.text = "\(tableExpense.expenseAmount ?? 0.0 )" //expense
        
     }
    
}
