//
//  UserCell.swift
//  Shyam_Modi

import UIKit

class UserCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    var user: UserData?{
        didSet{ //property observer
            userConfiguration()
        }
    }

    @IBOutlet weak var tripName: UILabel!
    @IBOutlet weak var destination: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
   func userConfiguration(){
       guard let user else{
           return
       }
       
       tripName.text = user.tripName  ?? "N/A" //trip name
       destination.text = "Destination: \(user.destination ?? "")" //destination
       
    }
    
}
