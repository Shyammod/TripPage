//
//  Database Manager.swift
//  Shyam_Modi


import UIKit
import CoreData


private var context: NSManagedObjectContext{
    return (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
}

class DatabaseManager{
    func adduser(_ user: UserModel){
        let userEntity = UserData(context: context)
        addUpdateUser(userEntity: userEntity, user: user)
    }
    
    func addexpense(_ user: Expenses){
        let userEntity = UserExpenses(context: context)
        addUpdateExpenses(userEntity: userEntity, user: user)
    }
    
    func updateUser(user: UserModel, userEntity: UserData){
        addUpdateUser(userEntity: userEntity, user: user)
        //Database : to view in database we have to save this data
    }

    func addUpdateUser(userEntity: UserData, user: UserModel){
        userEntity.tripName = user.tripName
        userEntity.startingLocation = user.startingLocation
        userEntity.destination = user.destination
        userEntity.startingDate = user.startingDate
        userEntity.endingDate = user.endingDate
        userEntity.bio = user.bio
        saveContext()
    }
    
    func addUpdateExpenses(userEntity: UserExpenses, user: Expenses){
        userEntity.tripName = user.tripName
        userEntity.expenseName = user.expenseName
        userEntity.expenseAmount = user.expenseAmount
        saveContext()
    }
    func fetchUser() -> [UserData] {
        var users: [UserData] = []
        do{
            users = try context.fetch(UserData.fetchRequest())
        }catch{
            print("Fetch user error", error)
        }
        return users
    }
   
    func fetchExpenses() -> [UserExpenses] {
        var users: [UserExpenses] = []
        do{
            users = try context.fetch(UserExpenses.fetchRequest())
        }catch{
            print("Fetch user error", error)
        }
        return users
    }
    func saveContext(){
        do{
            try context.save()
            print("Successful")//Most important
        }catch{
            print("User saving error, \(error)")
        }
    }
    
    
    func deleteUser(userEntity: UserData){
        context.delete(userEntity)
        saveContext()
    }
    
    func deleteExpense(userEntity: UserExpenses){
        context.delete(userEntity)
        saveContext()
    }
}
